// Canvas Setup
const canvas = document.getElementById('neonCanvas');
const ctx = canvas.getContext('2d');

let width = (canvas.width = window.innerWidth);
let height = (canvas.height = window.innerHeight);

window.addEventListener('resize', () => {
  width = canvas.width = window.innerWidth;
  height = canvas.height = window.innerHeight;
});

// Interactive Mouse Coordinates
const mouse = {
  x: width / 2,
  y: height / 2,
  targetX: width / 2,
  targetY: height / 2
};

window.addEventListener('mousemove', (e) => {
  mouse.targetX = e.clientX;
  mouse.targetY = e.clientY;
});

// Particle Burst Array for Clicks
const particles = [];

class Particle {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = Math.random() * 3.5 + 1.5; // Glowing Dot Size
    this.hue = Math.random() > 0.5 ? Math.random() * 40 + 170 : Math.random() * 40 + 300; // Cyan or Pink/Neon
    const angle = Math.random() * Math.PI * 2;
    const speed = Math.random() * 6 + 2;
    this.vx = Math.cos(angle) * speed;
    this.vy = Math.sin(angle) * speed;
    this.alpha = 1;
    this.decay = Math.random() * 0.02 + 0.015;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vx *= 0.95;
    this.vy *= 0.95;
    this.alpha -= this.decay;
  }

  draw() {
    ctx.save();
    ctx.globalAlpha = Math.max(this.alpha, 0);
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = `hsl(${this.hue}, 100%, 65%)`;
    ctx.shadowColor = `hsl(${this.hue}, 100%, 50%)`;
    ctx.shadowBlur = 12;
    ctx.fill();
    ctx.restore();
  }
}

// Click event for colorful dots burst
window.addEventListener('click', (e) => {
  for (let i = 0; i < 30; i++) {
    particles.push(new Particle(e.clientX, e.clientY));
  }
});

let time = 0;

// Render Neon Fractal Swirl Animation
function renderNeonWaves() {
  mouse.x += (mouse.targetX - mouse.x) * 0.05;
  mouse.y += (mouse.targetY - mouse.y) * 0.05;

  time += 0.006;

  // Dark background clearing with slight trailing effect
  ctx.fillStyle = '#020205';
  ctx.fillRect(0, 0, width, height);

  ctx.lineWidth = 5;

  // Render Neon Swirl Lines (Symmetric Cyan & Pink Spirals)
  const linesCount = 35;
  const centerY = height / 2;

  for (let i = 0; i < linesCount; i++) {
    ctx.beginPath();

    const isLeft = i % 2 === 0;
    const colorHue = isLeft ? 185 : 320; // 185 Cyan, 320 Neon Pink
    const dir = isLeft ? -1 : 1;

    for (let x = 0; x <= width; x += 12) {
      const dx = x - mouse.x;
      const mouseDist = Math.abs(dx);
      let mouseFactor = 0;

      if (mouseDist < 300) {
        mouseFactor = Math.cos((mouseDist / 300) * (Math.PI / 2)) * 50;
      }

      const wave1 = Math.sin(x * 0.003 + time * (1 + i * 0.05)) * (80 + i * 8);
      const wave2 = Math.cos(x * 0.008 - time * 0.8) * 30;
      const y = centerY + (wave1 + wave2 + mouseFactor * dir) * Math.sin(x * 0.001 + time * 0.2);

      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }

    ctx.strokeStyle = `hsla(${colorHue}, 100%, 60%, ${0.25 - i * 0.01})`;
    ctx.shadowColor = `hsl(${colorHue}, 100%, 50%)`;
    ctx.shadowBlur = 15;
    ctx.stroke();
  }


  requestAnimationFrame(renderNeonWaves);
}

renderNeonWaves();

// Password Field Toggle
const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('passwordInput');

togglePassword.addEventListener('click', () => {
  const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
  passwordInput.setAttribute('type', type);
  togglePassword.classList.toggle('fa-lock');
  togglePassword.classList.toggle('fa-lock-open');
});

// Extract User Name from Email Input
function extractNameFromEmail(email) {
  if (!email || !email.includes('@')) return 'User';

  const namePart = email.split('@')[0];
  const cleanName = namePart
    .replace(/[._-]/g, ' ')
    .replace(/[0-9]/g, '')
    .trim();

  if (!cleanName) return 'User';

  return cleanName
    .split(' ')
    .filter(word => word.length > 0)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

// 3D Card Flip Logic on Submit
const loginForm = document.getElementById('loginForm');
const cardInner = document.getElementById('cardInner');
const emailInput = document.getElementById('emailInput');
const displayName = document.getElementById('displayName');
const displayEmail = document.getElementById('displayEmail');
const logoutBtn = document.getElementById('logoutBtn');

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const userEmail = emailInput.value.trim();
  const userName = extractNameFromEmail(userEmail);

  displayName.textContent = userName;
  displayEmail.textContent = userEmail;

  // Flip Card 180 degrees
  cardInner.classList.add('is-flipped');
});

// Flip Back Logic
logoutBtn.addEventListener('click', () => {
  cardInner.classList.remove('is-flipped');
  loginForm.reset();
});