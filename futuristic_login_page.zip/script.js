const form = document.getElementById('loginForm');
const message = document.getElementById('formMessage');
const password = document.getElementById('password');
const togglePassword = document.getElementById('togglePassword');
const statusText = document.getElementById('statusText');
const bootText = document.getElementById('bootText');
const loginCard = document.querySelector('.login-card');
const loginFace = document.getElementById('loginFace');
const congratulationsFace = document.getElementById('congratulationsFace');
const welcomeName = document.getElementById('welcomeName');
const congratulationsHeading = document.getElementById('congratulationsHeading');
const returnToLogin = document.getElementById('returnToLogin');

// Restart the intro every time the page loads or is refreshed.
window.addEventListener('DOMContentLoaded', () => {
  document.body.classList.add('opening');
  window.setTimeout(() => {
    statusText.textContent = 'SECURE CHANNEL READY';
  }, 2700);
  window.setTimeout(() => {
    document.getElementById('username').focus({ preventScroll: true });
  }, 3300);
});

togglePassword.addEventListener('click', () => {
  const showing = password.type === 'text';
  password.type = showing ? 'password' : 'text';
  togglePassword.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
});

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const username = document.getElementById('username').value.trim();
  if (!username || !password.value) {
    message.style.color = '#ff8e9b';
    message.textContent = 'Please complete both fields.';
    return;
  }
  welcomeName.textContent = username;
  loginCard.classList.add('is-flipped');
  loginFace.setAttribute('aria-hidden', 'true');
  loginFace.setAttribute('inert', '');
  congratulationsFace.setAttribute('aria-hidden', 'false');
  congratulationsFace.removeAttribute('inert');
  statusText.textContent = 'DEMO ACCESS GRANTED';
  congratulationsHeading.focus({ preventScroll: true });
});

returnToLogin.addEventListener('click', () => {
  loginCard.classList.remove('is-flipped');
  loginFace.setAttribute('aria-hidden', 'false');
  loginFace.removeAttribute('inert');
  congratulationsFace.setAttribute('aria-hidden', 'true');
  congratulationsFace.setAttribute('inert', '');
  document.getElementById('username').focus({ preventScroll: true });
});

document.getElementById('forgotLink').addEventListener('click', (event) => {
  event.preventDefault();
  message.style.color = '#9ddfff';
  message.textContent = 'Password recovery needs to be connected to your app.';
});
