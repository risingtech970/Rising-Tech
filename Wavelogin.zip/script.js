// Interactive Water Wave Canvas Animation
const canvas = document.getElementById('waveCanvas');
const ctx = canvas.getContext('2d');

let width = (canvas.width = window.innerWidth);
let height = (canvas.height = window.innerHeight);

window.addEventListener('resize', () => {
  width = canvas.width = window.innerWidth;
  height = canvas.height = window.innerHeight;
});

// Wave properties
let step = 0;
const mouse = { x: width / 2, y: height / 2, radius: 150 };

window.addEventListener('mousemove', (e) => {
  mouse.x = e.clientX;
  mouse.y = e.clientY;
});

const waves = [
  { length: 0.01, amplitude: 30, speed: 0.02, color: 'rgba(0, 180, 216, 0.4)' },
  { length: 0.008, amplitude: 45, speed: 0.015, color: 'rgba(0, 119, 182, 0.3)' },
  { length: 0.005, amplitude: 60, speed: 0.01, color: 'rgba(3, 4, 94, 0.5)' }
];

function drawWaves() {
  ctx.clearRect(0, 0, width, height);

  // Background Gradient
  const bgGradient = ctx.createLinearGradient(0, 0, 0, height);
  bgGradient.addColorStop(0, '#030b1e');
  bgGradient.addColorStop(1, '#001833');
  ctx.fillStyle = bgGradient;
  ctx.fillRect(0, 0, width, height);

  step += 1;

  waves.forEach((wave, index) => {
    ctx.beginPath();
    ctx.moveTo(0, height);

    for (let x = 0; x <= width; x += 5) {
      // Calculate mouse influence
      const dist = Math.abs(x - mouse.x);
      let mouseEffect = 0;
      if (dist < mouse.radius) {
        mouseEffect = Math.sin((dist / mouse.radius) * Math.PI) * 20;
      }

      const y =
        Math.sin(x * wave.length + step * wave.speed) * wave.amplitude +
        mouseEffect +
        (height / 2 + index * 40);

      ctx.lineTo(x, y);
    }

    ctx.lineTo(width, height);
    ctx.closePath();
    ctx.fillStyle = wave.color;
    ctx.fill();
  });

  requestAnimationFrame(drawWaves);
}

drawWaves();

// Password Toggle Functionality
const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('passwordInput');

togglePassword.addEventListener('click', () => {
  const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
  passwordInput.setAttribute('type', type);
  
  togglePassword.classList.toggle('fa-eye');
  togglePassword.classList.toggle('fa-eye-slash');
});