// Radar Canvas Engine
const canvas = document.getElementById('radarCanvas');
const ctx = canvas.getContext('2d');

let width = (canvas.width = window.innerWidth);
let height = (canvas.height = window.innerHeight);

window.addEventListener('resize', () => {
  width = canvas.width = window.innerWidth;
  height = canvas.height = window.innerHeight;
});

// Radar Scan Parameters
let scanAngle = 0;
const scanSpeed = 0.02;

// Mouse Target Tracking
const mouse = { x: width / 2, y: height / 2 };
window.addEventListener('mousemove', (e) => {
  mouse.x = e.clientX;
  mouse.y = e.clientY;
});

// Radar Target Blips (Spawns targets dynamically + mouse clicks)
const targets = [];

function createTarget(x, y) {
  return {
    x: x,
    y: y,
    alpha: 1,
    size: Math.random() * 4 + 3,
    pulseRadius: 0
  };
}

// Populate random radar targets on background
for (let i = 0; i < 15; i++) {
  targets.push(createTarget(Math.random() * width, Math.random() * height));
}

// Add target on user click
window.addEventListener('click', (e) => {
  targets.push(createTarget(e.clientX, e.clientY));
});

// Main Radar Render Loop
function renderRadar() {
  // Clear canvas with faint trail for sweep effect
  ctx.fillStyle = 'rgba(2, 11, 8, 0.15)';
  ctx.fillRect(0, 0, width, height);

  const centerX = width / 2;
  const centerY = height / 2;
  const maxRadius = Math.max(width, height) * 0.75;

  ctx.save();
  ctx.translate(centerX, centerY);

  // 1. Draw Concentric Grid Rings
  ctx.strokeStyle = 'rgba(0, 255, 170, 0.15)';
  ctx.lineWidth = 1;

  for (let r = 80; r < maxRadius; r += 100) {
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.stroke();
  }

  // 2. Draw Crosshair Grid Lines
  ctx.beginPath();
  ctx.moveTo(-maxRadius, 0);
  ctx.lineTo(maxRadius, 0);
  ctx.moveTo(0, -maxRadius);
  ctx.lineTo(0, maxRadius);
  ctx.stroke();

  // 3. Draw Radar Rotating Sweep Beam
  scanAngle += scanSpeed;

  const sweepGradient = ctx.createConicGradient(scanAngle, 0, 0);
  sweepGradient.addColorStop(0, 'rgba(0, 255, 170, 0.4)');
  sweepGradient.addColorStop(0.1, 'rgba(0, 255, 170, 0.08)');
  sweepGradient.addColorStop(0.25, 'rgba(0, 255, 170, 0)');
  sweepGradient.addColorStop(1, 'rgba(0, 255, 170, 0)');

  ctx.fillStyle = sweepGradient;
  ctx.beginPath();
  ctx.arc(0, 0, maxRadius, 0, Math.PI * 2);
  ctx.fill();

  // 4. Rotating Outer HUD Degrees Ring
  ctx.save();
  ctx.rotate(scanAngle * 0.2);
  ctx.strokeStyle = 'rgba(0, 255, 170, 0.25)';
  ctx.setLineDash([4, 12]);
  ctx.beginPath();
  ctx.arc(0, 0, 280, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  ctx.restore();

  // 5. Draw & Ping Radar Targets (Blips)
  targets.forEach((target, index) => {
    const dx = target.x - centerX;
    const dy = target.y - centerY;
    const targetAngle = Math.atan2(dy, dx);
    
    // Normalize angles
    let angleDiff = scanAngle - targetAngle;
    angleDiff = Math.atan2(Math.sin(angleDiff), Math.cos(angleDiff));

    // When sweep line crosses target, ignite hit ping
    if (Math.abs(angleDiff) < 0.05) {
      target.alpha = 1;
      target.pulseRadius = target.size;
    }

    // Render Blip
    if (target.alpha > 0.05) {
      ctx.save();
      ctx.fillStyle = `rgba(0, 255, 170, ${target.alpha})`;
      ctx.shadowColor = '#00ffaa';
      ctx.shadowBlur = 10;

      // Target Dot
      ctx.beginPath();
      ctx.arc(target.x, target.y, target.size, 0, Math.PI * 2);
      ctx.fill();

      // Target Radar Pulse Ring
      ctx.strokeStyle = `rgba(0, 255, 170, ${target.alpha * 0.6})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(target.x, target.y, target.pulseRadius, 0, Math.PI * 2);
      ctx.stroke();

      target.pulseRadius += 0.8;
      target.alpha *= 0.985; // Gradual fade
      ctx.restore();
    }
  });

  requestAnimationFrame(renderRadar);
}

renderRadar();

// Password Field Toggle
const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('passwordInput');

togglePassword.addEventListener('click', () => {
  const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
  passwordInput.setAttribute('type', type);
  togglePassword.classList.toggle('fa-eye');
  togglePassword.classList.toggle('fa-eye-slash');
});

// Smart Email Name Extractor
function extractNameFromEmail(email) {
  if (!email || !email.includes('@')) return 'AGENT';

  const namePart = email.split('@')[0];
  const cleanName = namePart.replace(/[._-]/g, ' ').replace(/[0-9]/g, '').trim();

  if (!cleanName) return 'AGENT';

  return cleanName
    .split(' ')
    .filter(w => w.length > 0)
    .map(w => w.toUpperCase())
    .join(' ');
}

// 3D Card Flip Logic on Submit
const loginForm = document.getElementById('loginForm');
const cardInner = document.getElementById('cardInner');
const emailInput = document.getElementById('emailInput');
const displayName = document.getElementById('displayName');
const displayEmail = document.getElementById('displayEmail');
const logoutBtn = document.getElementById('logoutBtn');

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const userEmail = emailInput.value.trim();
  const userName = extractNameFromEmail(userEmail);

  displayName.textContent = userName;
  displayEmail.textContent = userEmail;

  cardInner.classList.add('is-flipped');
});

// Return / Logout Flip Back
logoutBtn.addEventListener('click', () => {
  cardInner.classList.remove('is-flipped');
  loginForm.reset();
});